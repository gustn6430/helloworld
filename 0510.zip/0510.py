#0510

import random

print("random.randint(10,100) ",random.randint(10,100))

import math as m

print(m.fsum([1,1,1,1,1,1]))
print(m.pow(10,3))  # 10의 3승

from math import pow
print(pow(10,3))

from math import pow as p
print(p(10,3))

from math import pow,fsum
print(pow(10,3))
print(m.fsum([1,1,1,1,1,1]))


#0510.py
import ya
print("=========================")
ya.helloya()

print("__name in 0510.py : ",__name__)  # main

from moduley.ai import ya as selected
selected.hello10()



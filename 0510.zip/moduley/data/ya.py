#ya.py

#author : 김현수

def helloya() :
    print("hello! YA . in ya.py")

if __name__=="__main__" :
    print("오늘은 5월 10일입니다.")
    helloya()
    print("축제시작 곧 합니다.")
    print("__name in ya.py : ", __name__)